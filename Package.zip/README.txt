Phantom Forces Font Changer
Brought to you by Over-Alphine
DO NOT DELETE ANY FILE CONTAINED IN THE ZIP FILE!!!!


How to use this?
Get two .ttf font files you like to apply.
Copy them to the folder where you extracted this batch files and text file.
Rename one as "killfeed.ttf" and the other as "UI.ttf."
Execute RunMe.bat, follow the instructions there and wait until command prompt disappears.
Done! Now execute roblox and check if it's applied successfully!