Phantom Forces Font Changer(Version 1.0.1)
Brought to you by Over-Alphine
DO NOT DELETE ANY FILE CONTAINED IN THE ZIP FILE!
ALSO, LET TERMINAL CLOSE AUTOMATICALLY! Make sure to delete changer.bat and ttf files if you closed terminal manually.
By using this tool, you agree that I don't have any responsibilities on your inconveniences while gaming, such as game crash.


How to use this?
Get two .ttf font files you like to apply.
Copy them to the folder where you extracted this batch files and text file.
Rename one as "killfeed.ttf" and the other as "UI.ttf."
Execute RunMe.bat, follow the instructions there and wait until command prompt disappears.
Done! Now execute roblox and check if it's applied successfully!

--changelog--
Ver 1.0.1, released on Dec 04, 2020
Fixed bug

Ver 1.0.0, released on Dec 04, 2020
Initial release